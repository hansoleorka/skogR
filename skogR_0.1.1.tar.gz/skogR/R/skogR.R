.onAttach <- function(lib, pkg)
  cat( c( "skogR version 0.1.1 - WARNING BETA VERSION", "Created 24. Januar 2013","Type skogR.News() to see new features/changes/bug fixes."), sep="\n")
